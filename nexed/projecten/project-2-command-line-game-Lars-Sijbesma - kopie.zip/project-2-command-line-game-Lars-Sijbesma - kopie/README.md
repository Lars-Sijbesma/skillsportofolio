# Command Line Game Lars

Trello:
https://trello.com/b/qGxmeMio/project

1.Hoe start je de game: `python .\project-game.py` (python en dan de file naam)
<br>
2.Hoe de game werkt:je begint met een alien kiesen om mee te vechten, sommige hebben geneseden moves en meeste zijn damage.
Het gaat om de beurt, als je transformatie correct is, dan val je als eerste aan als niet dan gaat de vijand eerst.
Je verandert na 5 beurten in alien vorm terug naar normaal en kan daarna niet meer de alien gebruiken, in deze terug transformatie kan je een nieuwe alien ontgrendelen, alle aliens ontgrendelen, in een willekeurige alien veranderen en dan weer vechten of en alien kiesen en weer vechten
Dit gaat 15 keer door totdat je of al je aliens uit heb geput of totdat je de 15 vijanden heb verslagen



Trello link:https://trello.com/b/qGxmeMio/project